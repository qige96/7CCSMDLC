const ownershipLimit = 2
const initialQuotes = [3, 6, 9, 12, 15, 18, 21, 24, 27, 30]
const initialWhilelisted = [
    "0x10241F86e65c97eDc4599360cB6C15475F0F2d15",
    "0xf39e8868Cc10D387e60176C796eF968C9db77dA5",
    "0x647bccef043B01F24d7b53D487eDb1c7a962Dde7"
]

module.exports = {
    ownershipLimit,
    initialQuotes,
    initialWhilelisted
}
